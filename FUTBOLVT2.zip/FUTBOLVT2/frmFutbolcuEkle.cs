﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FUTBOLVT2
{
    public partial class frmFutbolcuEkle : Form
    {
        Futbol futbolcu = new Futbol();
        public frmFutbolcuEkle()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string cumle = "insert into FUTBOLCULAR (F_TC,F_AD,F_YAS,F_POZ,F_TAK_ID) values(@F_TC,@F_AD,@F_YAS,@F_POZ,@F_TAK_ID)";
            SqlCommand komut2 = new SqlCommand();
            komut2.Parameters.AddWithValue("@F_TC", txtTc.Text);
            komut2.Parameters.AddWithValue("@F_AD", txtAd.Text);
            komut2.Parameters.AddWithValue("@F_YAS", txtYas.Text);
            komut2.Parameters.AddWithValue("@F_POZ", txtPoz.Text);
            komut2.Parameters.AddWithValue("@F_TAK_ID", txtTakid.Text);
            futbolcu.ekle_sil_güncelle(komut2, cumle);
            foreach (Control item in Controls) if (item is TextBox) item.Text = "";
        }
    }
}
    