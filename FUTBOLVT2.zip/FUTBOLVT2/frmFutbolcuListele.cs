﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FUTBOLVT2
{
    public partial class frmFutbolcuListele : Form
    {
        Futbol futbolcu = new Futbol();

        public frmFutbolcuListele()
        {
            InitializeComponent();
        }

        private void btn_ekle_Click(object sender, EventArgs e)
        {
            string cümle = "update FUTBOLCULAR set F_TC=@F_TC,F_AD=@F_AD,F_YAS=@F_YAS,F_POZ=@F_POZ,F_TAK_ID=@F_TAK_ID WHERE F_TC=@F_TC ";
            SqlCommand komut2 = new SqlCommand();
            komut2.Parameters.AddWithValue("@F_TC", txtTc.Text);
            komut2.Parameters.AddWithValue("@F_AD", txtAd.Text);
            komut2.Parameters.AddWithValue("@F_YAS", txtYas.Text);
            komut2.Parameters.AddWithValue("@F_POZ", txtPoz.Text);
            komut2.Parameters.AddWithValue("@F_TAK_ID", txtTakid.Text);
            futbolcu.ekle_sil_güncelle(komut2, cümle);
            foreach (Control item in Controls) if (item is TextBox) item.Text = "";
            YenileListele();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DataGridViewRow satır = dataGridView1.CurrentRow;
            string cümle = "delete from FUTBOLCULAR where F_TC= '" + satır.Cells["F_TC"].Value.ToString() + "' ";
            SqlCommand komut2=new SqlCommand();
            futbolcu.ekle_sil_güncelle(komut2, cümle);
            foreach (Control item in Controls) if (item is TextBox) item.Text = "";
            YenileListele();
        }

        private void frmFutbolcuListele_Load(object sender, EventArgs e)
        {
            YenileListele();
        }
        private void YenileListele()
        {
            string cümle = "select * from FUTBOLCULAR";

            SqlDataAdapter adtr2 = new SqlDataAdapter();
            dataGridView1.DataSource = futbolcu.listele(adtr2, cümle);
            dataGridView1.Columns[1].HeaderText = "TC";
            dataGridView1.Columns[2].HeaderText = "AD SOYAD";
            dataGridView1.Columns[3].HeaderText = "YAŞ";
            dataGridView1.Columns[4].HeaderText = "POZİSYON";
            dataGridView1.Columns[5].HeaderText = "TAKIM ID";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string cümle = "select * from FUTBOLCULAR where F_TC like '%"+textBox1.Text +"%'";
            SqlDataAdapter adtr2 = new SqlDataAdapter();
          
            dataGridView1.DataSource = futbolcu.listele(adtr2, cümle);
        }

        private void btn_iptal_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow satır = dataGridView1.CurrentRow;
            txtTc.Text = satır.Cells[1].Value.ToString();
            txtAd.Text = satır.Cells[2].Value.ToString();
            txtYas.Text = satır.Cells[3].Value.ToString();
            txtPoz.Text = satır.Cells[4].Value.ToString();
            txtTakid.Text = satır.Cells[5].Value.ToString();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txtTc_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtAd_TextChanged(object sender, EventArgs e)
        {

        }
    }
    }

