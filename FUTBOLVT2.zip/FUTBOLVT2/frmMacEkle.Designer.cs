﻿namespace FUTBOLVT2
{
    partial class frmMacEkle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_iptal = new System.Windows.Forms.Button();
            this.btn_ekle = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtDepId = new System.Windows.Forms.TextBox();
            this.txtEvSkor = new System.Windows.Forms.TextBox();
            this.txtDepSkor = new System.Windows.Forms.TextBox();
            this.txtEvId = new System.Windows.Forms.TextBox();
            this.txtTarih = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_iptal
            // 
            this.btn_iptal.Location = new System.Drawing.Point(169, 276);
            this.btn_iptal.Name = "btn_iptal";
            this.btn_iptal.Size = new System.Drawing.Size(78, 23);
            this.btn_iptal.TabIndex = 25;
            this.btn_iptal.Text = "İptal";
            this.btn_iptal.UseVisualStyleBackColor = true;
            // 
            // btn_ekle
            // 
            this.btn_ekle.Location = new System.Drawing.Point(56, 276);
            this.btn_ekle.Name = "btn_ekle";
            this.btn_ekle.Size = new System.Drawing.Size(75, 23);
            this.btn_ekle.TabIndex = 24;
            this.btn_ekle.Text = "Maç Ekle";
            this.btn_ekle.UseVisualStyleBackColor = true;
            this.btn_ekle.Click += new System.EventHandler(this.btn_ekle_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(53, 202);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(38, 16);
            this.label6.TabIndex = 23;
            this.label6.Text = "Tarih";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(53, 160);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(64, 16);
            this.label5.TabIndex = 22;
            this.label5.Text = "Dep Skor";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(53, 118);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 16);
            this.label4.TabIndex = 21;
            this.label4.Text = "Ev Skor";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(53, 76);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 16);
            this.label3.TabIndex = 20;
            this.label3.Text = "Dep Id";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(53, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 16);
            this.label2.TabIndex = 19;
            this.label2.Text = "Ev Id";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // txtDepId
            // 
            this.txtDepId.Location = new System.Drawing.Point(121, 73);
            this.txtDepId.Name = "txtDepId";
            this.txtDepId.Size = new System.Drawing.Size(100, 22);
            this.txtDepId.TabIndex = 18;
            // 
            // txtEvSkor
            // 
            this.txtEvSkor.Location = new System.Drawing.Point(121, 115);
            this.txtEvSkor.Name = "txtEvSkor";
            this.txtEvSkor.Size = new System.Drawing.Size(100, 22);
            this.txtEvSkor.TabIndex = 17;
            // 
            // txtDepSkor
            // 
            this.txtDepSkor.Location = new System.Drawing.Point(121, 157);
            this.txtDepSkor.Name = "txtDepSkor";
            this.txtDepSkor.Size = new System.Drawing.Size(100, 22);
            this.txtDepSkor.TabIndex = 16;
            // 
            // txtEvId
            // 
            this.txtEvId.Location = new System.Drawing.Point(121, 31);
            this.txtEvId.Name = "txtEvId";
            this.txtEvId.Size = new System.Drawing.Size(100, 22);
            this.txtEvId.TabIndex = 15;
            // 
            // txtTarih
            // 
            this.txtTarih.Location = new System.Drawing.Point(121, 199);
            this.txtTarih.Name = "txtTarih";
            this.txtTarih.Size = new System.Drawing.Size(100, 22);
            this.txtTarih.TabIndex = 14;
            // 
            // frmMacEkle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Highlight;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_iptal);
            this.Controls.Add(this.btn_ekle);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtDepId);
            this.Controls.Add(this.txtEvSkor);
            this.Controls.Add(this.txtDepSkor);
            this.Controls.Add(this.txtEvId);
            this.Controls.Add(this.txtTarih);
            this.Name = "frmMacEkle";
            this.Text = "frmMacEkle";
            this.Load += new System.EventHandler(this.frmMacEkle_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_iptal;
        private System.Windows.Forms.Button btn_ekle;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtDepId;
        private System.Windows.Forms.TextBox txtEvSkor;
        private System.Windows.Forms.TextBox txtDepSkor;
        private System.Windows.Forms.TextBox txtEvId;
        private System.Windows.Forms.TextBox txtTarih;
    }
}