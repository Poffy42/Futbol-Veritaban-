﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FUTBOLVT2
{
    public partial class frmMacEkle : Form
    {
        Futbol maclar= new Futbol();
        public frmMacEkle()
        {
            InitializeComponent();
        }

        private void frmMacEkle_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btn_ekle_Click(object sender, EventArgs e)
        {
            string cümle = "insert into MACLAR(M_EV_ID,M_DEP_ID,M_EV_SKOR,M_DEP_SKOR,M_TARIH)VALUES(@M_EV_ID,@M_DEP_ID,@M_EV_SKOR,@M_DEP_SKOR,@M_TARIH)";
            SqlCommand komut2 = new SqlCommand();
            komut2.Parameters.AddWithValue("@M_EV_ID",txtEvId.Text);
            komut2.Parameters.AddWithValue("@M_DEP_ID", txtDepId.Text);
            komut2.Parameters.AddWithValue("@M_EV_SKOR", txtEvSkor.Text);
            komut2.Parameters.AddWithValue("@M_DEP_SKOR", txtDepSkor.Text);
            komut2.Parameters.AddWithValue("@M_TARIH", txtTarih.Text);
            maclar.ekle_sil_güncelle(komut2, cümle);
        }   
            
    }
}
