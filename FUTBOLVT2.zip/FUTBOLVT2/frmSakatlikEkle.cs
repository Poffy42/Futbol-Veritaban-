﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FUTBOLVT2
{
    public partial class frmSakatlikEkle : Form
    {
        Futbol sakatlik=new Futbol();
        public frmSakatlikEkle()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btn_ekle_Click(object sender, EventArgs e)
        {
            string cumle = "insert into SAKATLIKLAR (S_TARIH,S_TANI,F_ID) values(@S_TARIH,@S_TANI,@F_ID)";
            SqlCommand komut2 = new SqlCommand();
            komut2.Parameters.AddWithValue("@S_TARIH", txtTarih.Text);
            komut2.Parameters.AddWithValue("@S_TANI", txtTanı.Text);
            komut2.Parameters.AddWithValue("@F_ID",txtFid.Text);
            sakatlik.ekle_sil_güncelle(komut2, cumle);
            foreach (Control item in Controls) if (item is TextBox) item.Text = "";
        }
    }
}
