﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FUTBOLVT2
{
    public partial class frmSakatlikGoster : Form
    {
        Futbol sakatlikgoster = new Futbol();
        public frmSakatlikGoster()
        {
            InitializeComponent();
        }

        private void frmSakatlikGoster_Load(object sender, EventArgs e)
        {
            SakatlikGoster();
        }
        private void SakatlikGoster()
        {
            string cümle = "select * from SakatlikGoster";
            SqlDataAdapter adtr2 = new SqlDataAdapter();
            dataGridView1.DataSource = sakatlikgoster.listele(adtr2, cümle);

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
