﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FUTBOLVT2
{
    public partial class frmTakımlarıListele : Form
    {
        Futbol takım = new Futbol();
        public frmTakımlarıListele()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtAd_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_güncelle_Click(object sender, EventArgs e)
        {
            string cümle = "update TAKIMLAR set T_AD=@T_AD,T_TD=@T_TD,T_SEHIR=@T_SEHIR where T_AD=@T_AD  ";
            SqlCommand komut2 = new SqlCommand();
            komut2.Parameters.AddWithValue("@T_AD", txtAd.Text);
            komut2.Parameters.AddWithValue("@T_TD", txtTd.Text);
            komut2.Parameters.AddWithValue("@T_SEHIR", txtSehir.Text);
            takım.ekle_sil_güncelle(komut2, cümle);
            foreach (Control item in Controls) if (item is TextBox) item.Text = "";
            YenileListele();
            
        }

        private void frmTakımlarıListele_Load(object sender, EventArgs e)
        {
            YenileListele();
        }
        private void YenileListele()
        {
            string cümle = "SELECT * FROM TAKIMLAR";
            SqlDataAdapter adtr2 = new SqlDataAdapter();
            dataGridView1.DataSource = takım.listele(adtr2, cümle);

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btn_iptal_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_iptal_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow satır = dataGridView1.CurrentRow;
            txtAd.Text = satır.Cells[1].Value.ToString();
            txtTd.Text = satır.Cells[2].Value.ToString();
            txtSehir.Text = satır.Cells[3].Value.ToString();
        }
    }
}
